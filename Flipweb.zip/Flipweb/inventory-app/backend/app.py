from flask import Flask, jsonify, request
from google.cloud import bigquery
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for cross-origin requests

# Initialize BigQuery client
client = bigquery.Client()

# Define the table name in BigQuery
project_id = "flipkart-438204"
dataset_id = "inventory"
table_id = "rack"
table_ref = f"{project_id}.{dataset_id}.{table_id}"

@app.route('/items', methods=['GET'])
def get_items():
    """Fetch all items from BigQuery table."""
    try:
        query = f"SELECT * FROM {table_ref}"
        query_job = client.query(query)  # Run the query
        results = query_job.result()  # Wait for the job to complete

        items = []
        for row in results:
            items.append({
                "ID": row.ID,
                "name": row.name,
                "brand": row.brand,
                "in_time": row.in_time,
                "out_time": row.out_time,
                "manu_date": row.manu_date,
                "exp_date": row.exp_date,
                "price": row.price,
                "quantity": row.quantity,
                "total": row.total,
                "color": row.color,
                "qr": row.qr
            })
        return jsonify(items), 200

    except Exception as e:
        print(f"Error occurred: {str(e)}")
        return jsonify({"error": f"Internal Server Error: {str(e)}"}), 500

@app.route('/add-item', methods=['POST'])
def add_item():
    """Insert a new item into the BigQuery table."""
    try:
        data = request.get_json()

        required_fields = ["name", "brand", "in_time", "out_time", "manu_date", "exp_date", "price", "quantity", "total", "color", "qr"]

        # Check for required fields and allow null values
        for field in required_fields:
            if field not in data:
                data[field] = None  # Set to None if missing to allow null

        # Fetch the current maximum ID to increment
        query = f"SELECT MAX(ID) as max_id FROM {table_ref}"
        query_job = client.query(query)
        result = query_job.result()
        max_id_row = list(result)

        # If there are no items, start from 1, otherwise increment the max ID
        if max_id_row and max_id_row[0].max_id is not None:
            new_id = max_id_row[0].max_id + 1
        else:
            new_id = 1  # Start from 1 if the table is empty

        rows_to_insert = [{
            "ID": new_id,
            "name": data["name"],
            "brand": data["brand"],
            "in_time": data["in_time"],
            "out_time": data["out_time"],
            "manu_date": data["manu_date"],
            "exp_date": data["exp_date"],
            "price": data["price"],
            "quantity": data["quantity"],
            "total": data["total"],
            "color": data["color"],
            "qr": data["qr"]
        }]

        table = client.get_table(table_ref)
        errors = client.insert_rows_json(table, rows_to_insert)

        if errors:
            return jsonify({"error": errors}), 400
        return jsonify({"message": "Item added successfully"}), 201

    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({"error": "Internal Server Error"}), 500

@app.route('/update-item/<item_id>', methods=['PUT'])
def update_item(item_id):
    """Update an existing item in the BigQuery table (full replacement)."""
    try:
        data = request.get_json()

        # Allow all fields to be nullable
        update_fields = []
        for field in data.keys():
            update_fields.append(f"{field} = @param_{field}")

        query = f"""
        UPDATE {table_ref}
        SET {', '.join(update_fields)}
        WHERE ID = @item_id
        """
        
        job_config = bigquery.QueryJobConfig(
            query_parameters=[ 
                bigquery.ScalarQueryParameter("item_id", "INTEGER", item_id),  # Change to INTEGER if ID is an integer
                *[bigquery.ScalarQueryParameter(f"param_{field}", "STRING" if isinstance(data[field], str) else "FLOAT" if isinstance(data[field], float) else "INTEGER", data[field]) for field in data.keys()]
            ]
        )

        query_job = client.query(query, job_config=job_config)
        query_job.result()

        return jsonify({"message": f"Item with ID {item_id} updated successfully"}), 200

    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({"error": "Internal Server Error"}), 500

@app.route('/modify-item/<item_id>', methods=['PATCH'])
def modify_item(item_id):
    """Partially update an existing item in the BigQuery table."""
    try:
        data = request.get_json()

        if not data:
            return jsonify({"error": "No fields provided for update"}), 400

        update_fields = []
        for field, value in data.items():
            update_fields.append(f"{field} = @param_{field}")

        query = f"""
        UPDATE {table_ref}
        SET {', '.join(update_fields)}
        WHERE ID = @item_id
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("item_id", "INTEGER", item_id),  # Change to INTEGER if ID is an integer
                *[bigquery.ScalarQueryParameter(f"param_{field}", "STRING" if isinstance(value, str) else "FLOAT" if isinstance(value, float) else "INTEGER", value) for field, value in data.items()]
            ]
        )

        query_job = client.query(query, job_config=job_config)
        query_job.result()

        return jsonify({"message": f"Item with ID {item_id} modified successfully"}), 200

    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({"error": "Internal Server Error"}), 500

@app.route('/delete-item/<item_id>', methods=['DELETE'])
def delete_item(item_id):
    """Delete an item from the BigQuery table."""
    try:
        query = f"DELETE FROM {table_ref} WHERE ID = @item_id"
        
        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("item_id", "INTEGER", item_id)  # Change to INTEGER if ID is an integer
            ]
        )

        query_job = client.query(query, job_config=job_config)
        query_job.result()

        return jsonify({"message": f"Item with ID {item_id} deleted successfully"}), 200

    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({"error": "Internal Server Error"}), 500

if __name__ == '__main__':
    app.run(debug=True)
