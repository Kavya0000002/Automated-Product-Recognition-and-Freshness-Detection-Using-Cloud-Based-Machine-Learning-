import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css'; // Adjust the path if needed

const App = () => {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState({
    name: '',
    brand: '',
    in_time: '',
    out_time: '',
    manu_date: '',
    exp_date: '',
    price: '',
    quantity: '',
    total: '',
    color: '',
    qr: ''
  });
  const [view, setView] = useState('table'); // State to manage the view
  const [isStockIn, setIsStockIn] = useState(true); // State to toggle Stock In / Stock Out

  // Fetch items from the backend
  const fetchItems = async () => {
    try {
      const response = await axios.get('http://localhost:5000/items');
      setItems(response.data);
    } catch (error) {
      console.error('Error fetching items:', error);
    }
  };

  // Add a new item or update existing item
  const handleAddOrUpdateItem = async () => {
    try {
      if (isStockIn) {
        // Adding a new item for Stock In
        await axios.post('http://localhost:5000/add-item', newItem);
      } else {
        // Updating the item for Stock Out
        await axios.put('http://localhost:5000/update-item', newItem); // Assume you have an endpoint for updating items
      }
      fetchItems(); // Refresh the item list
      resetForm();
    } catch (error) {
      console.error('Error adding/updating item:', error);
    }
  };

  const resetForm = () => {
    setNewItem({
      name: '',
      brand: '',
      in_time: '',
      out_time: '',
      manu_date: '',
      exp_date: '',
      price: '',
      quantity: '',
      total: '',
      color: '',
      qr: ''
    });
  };

  useEffect(() => {
    fetchItems();
  }, []);

  // Render items in table format
  const renderItemsTable = () => (
    <div>
      <h2>Items Table</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Brand</th>
            <th>In Time</th>
            <th>Out Time</th>
            <th>Manufacture Date</th>
            <th>Expiry Date</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Color</th>
            <th>QR</th>
          </tr>
        </thead>
        <tbody>
          {items.map(item => (
            <tr key={item.ID}>
              <td>{item.name}</td>
              <td>{item.brand}</td>
              <td>{item.in_time}</td>
              <td>{item.out_time}</td>
              <td>{item.manu_date}</td>
              <td>{item.exp_date}</td>
              <td>{item.price}</td>
              <td>{item.quantity}</td>
              <td>{item.total}</td>
              <td>{item.color}</td>
              <td>{item.qr}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  // Render in-stock items
  const renderInStockItems = () => (
    <div>
      <h2>In Stock Items</h2>
      <ul>
        {items.map(item => (
          item.quantity > 0 && ( // Only show items with quantity > 0
            <li key={item.ID}>
              {item.name} - {item.brand} - {item.price}
            </li>
          )
        ))}
      </ul>
    </div>
  );

  return (
    <div>
      <h1>Item Inventory</h1>
      
      <div>
        <button onClick={() => setView('table')}>View Table</button>
        <button onClick={() => setView('enter')}>Enter Manually</button>
        <button onClick={() => setView('inStock')}>In Stock Items</button>
      </div>

      {view === 'table' && renderItemsTable()}
      {view === 'enter' && (
        <div>
          <h2>{isStockIn ? 'Stock In' : 'Stock Out'}</h2>
          <button onClick={() => setIsStockIn(true)}>Stock In</button>
          <button onClick={() => setIsStockIn(false)}>Stock Out</button>

          <div>
            <input type="text" placeholder="Name" value={newItem.name} onChange={(e) => setNewItem({ ...newItem, name: e.target.value })} />
            <input type="text" placeholder="Brand" value={newItem.brand} onChange={(e) => setNewItem({ ...newItem, brand: e.target.value })} />
            {isStockIn ? (
              <>
                <input type="text" placeholder="In Time" value={newItem.in_time} onChange={(e) => setNewItem({ ...newItem, in_time: e.target.value })} />
                <input type="text" placeholder="Manufacture Date" value={newItem.manu_date} onChange={(e) => setNewItem({ ...newItem, manu_date: e.target.value })} />
                <input type="text" placeholder="Expiry Date" value={newItem.exp_date} onChange={(e) => setNewItem({ ...newItem, exp_date: e.target.value })} />
                <input type="text" placeholder="Price" value={newItem.price} onChange={(e) => setNewItem({ ...newItem, price: e.target.value })} />
                <input type="text" placeholder="Quantity" value={newItem.quantity} onChange={(e) => setNewItem({ ...newItem, quantity: e.target.value })} />
                <input type="text" placeholder="Total" value={newItem.total} onChange={(e) => setNewItem({ ...newItem, total: e.target.value })} />
                <input type="text" placeholder="Color" value={newItem.color} onChange={(e) => setNewItem({ ...newItem, color: e.target.value })} />
                <input type="text" placeholder="QR" value={newItem.qr} onChange={(e) => setNewItem({ ...newItem, qr: e.target.value })} />
              </>
            ) : (
              <>
                <input type="text" placeholder="Out Time" value={newItem.out_time} onChange={(e) => setNewItem({ ...newItem, out_time: e.target.value })} />
                <input type="text" placeholder="Manufacture Date" value={newItem.manu_date} onChange={(e) => setNewItem({ ...newItem, manu_date: e.target.value })} />
                <input type="text" placeholder="Expiry Date" value={newItem.exp_date} onChange={(e) => setNewItem({ ...newItem, exp_date: e.target.value })} />
                <input type="text" placeholder="Price" value={newItem.price} onChange={(e) => setNewItem({ ...newItem, price: e.target.value })} />
                <input type="text" placeholder="Quantity" value={newItem.quantity} onChange={(e) => setNewItem({ ...newItem, quantity: e.target.value })} />
                <input type="text" placeholder="Total" value={newItem.total} onChange={(e) => setNewItem({ ...newItem, total: e.target.value })} />
                <input type="text" placeholder="Color" value={newItem.color} onChange={(e) => setNewItem({ ...newItem, color: e.target.value })} />
                <input type="text" placeholder="QR" value={newItem.qr} onChange={(e) => setNewItem({ ...newItem, qr: e.target.value })} />
              </>
            )}
            <button onClick={handleAddOrUpdateItem}>{isStockIn ? 'Add Item' : 'Update Item'}</button>
          </div>
        </div>
      )}
      {view === 'inStock' && renderInStockItems()}
    </div>
  );
};

export default App;
